package adoptioncenter.model;

/**
 * NewExoticAnimal used to better handle Adapter
 */
public class NewExoticAnimal extends ExoticAnimal {
    private final String category, subSpecies, name, uniqueId;
    private final int yearsOld;

    public NewExoticAnimal(String category, String subSpecies, int yearsOld, String name, String uniqueId) {
        this.category = category;
        this.subSpecies = subSpecies;
        this.yearsOld = yearsOld;
        this.name = name;
        this.uniqueId = uniqueId;
    }

    @Override public String getCategory() {
    	return category; 
    	}
    @Override public String getSubSpecies() {
    	return subSpecies; 
    	}
    @Override public int getYearsOld() {
    	return yearsOld; 
    	}
    @Override public String getAnimalName() {
    	return name; 
    	}
    @Override public String getUniqueId() {
    	return uniqueId; 
    	}
}