package adoptioncenter.model;

import com.google.gson.*;
import java.io.*;
import java.util.*;

public class PetLoader {

    public static List<Pet> loadPets() throws IOException {
        File saveFile = new File("saved_pets.json");
        if (saveFile.exists()) {
            return loadPets("saved_pets.json");
        } else {
            return loadPets("src/main/resources/pets.json");
        }
    }

    public static List<Pet> loadPets(String filePath) throws IOException {
        Gson gson = new Gson();
        JsonArray jsonArray = JsonParser.parseReader(new FileReader(filePath)).getAsJsonArray();

        List<Pet> pets = new ArrayList<>();
        for (JsonElement element : jsonArray) {
            JsonObject obj = element.getAsJsonObject();
            String type = obj.get("type").getAsString();
            int id = obj.get("id").getAsInt();
            String name = obj.get("name").getAsString();
            String species = obj.get("species").getAsString();
            int age = obj.get("age").getAsInt();
            boolean adopted = obj.get("adopted").getAsBoolean();

            switch (type) {
                case "Dog":
                    pets.add(new Dog(id, name, type, species, age, adopted));
                    break;
                case "Cat":
                    pets.add(new Cat(id, name, type, species, age, adopted));
                    break;
                case "Rabbit":
                    pets.add(new Rabbit(id, name, type, species, age, adopted));
                    break;
                default:
                	ExoticAnimal exotic = new NewExoticAnimal(type, species, age, name, "id-" + id);
                	ExoticPet exoticPet = ExoticAnimalAdapter.adapt(exotic, id);
                	exoticPet.setAdopted(adopted);
                	pets.add(exoticPet);
                	break;
            }
        }
        return pets;
    }
}


