package adoptioncenter.view;

import adoptioncenter.model.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

/**
 * GUI window for the Pet Adoption Center.
 */
public class PetAdoptionGUI extends JFrame {
    private DefaultListModel<Pet> listModel = new DefaultListModel<>();
    private JList<Pet> petList = new JList<>(listModel);
    private JComboBox<String> sortCombo = new JComboBox<>(new String[]{"Name", "Age", "Species"});
    private JButton addButton = new JButton("Add Pet");
    private JButton adoptButton = new JButton("Adopt");
    private JButton removeButton = new JButton("Remove");
    private JButton saveButton = new JButton("Save");

    public PetAdoptionGUI() {
        setTitle("Pet Adoption Center");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(new JScrollPane(petList), BorderLayout.CENTER);

        JPanel controls = new JPanel();
        controls.add(sortCombo);
        controls.add(addButton);
        controls.add(adoptButton);
        controls.add(removeButton);
        controls.add(saveButton);
        add(controls, BorderLayout.SOUTH);
    }

    public void setPetList(List<Pet> pets) {
        listModel.clear();
        for (Pet p : pets) listModel.addElement(p);
    }

    public Pet getSelectedPet() {
        return petList.getSelectedValue();
    }

    public void setAddPetAction(java.awt.event.ActionListener listener) {
        addButton.addActionListener(listener);
    }

    public void setAdoptPetAction(java.awt.event.ActionListener listener) {
        adoptButton.addActionListener(listener);
    }

    public void setRemovePetAction(java.awt.event.ActionListener listener) {
        removeButton.addActionListener(listener);
    }

    public void setSaveAction(java.awt.event.ActionListener listener) {
        saveButton.addActionListener(listener);
    }

    public void setSortAction(Consumer<String> sorter) {
        sortCombo.addActionListener(e -> {
            String option = (String) sortCombo.getSelectedItem();
            sorter.accept(option);
        });
    }

    public Pet promptNewPet() {
        JTextField name = new JTextField();
        JTextField type = new JTextField();
        JTextField species = new JTextField();
        JTextField age = new JTextField();

        Object[] fields = {
            "Name:", name,
            "Type (Dog, Cat, Rabbit):", type,
            "Species:", species,
            "Age:", age
        };

        int result = JOptionPane.showConfirmDialog(this, fields, "Add New Pet", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                int ageVal = Integer.parseInt(age.getText().trim());
                String t = type.getText().trim().toLowerCase();

                switch (t) {
                    case "dog":
                        return new Dog(0, name.getText(), "Dog", species.getText(), ageVal, false);
                    case "cat":
                        return new Cat(0, name.getText(), "Cat", species.getText(), ageVal, false);
                    case "rabbit":
                        return new Rabbit(0, name.getText(), "Rabbit", species.getText(), ageVal, false);
                    default:
                        ExoticAnimal exotic = new NewExoticAnimal(type.getText(), species.getText(), ageVal, name.getText(), "temp-id");
                        ExoticPet exoticPet = ExoticAnimalAdapter.adapt(exotic, 0);
                        return exoticPet;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid age.");
            }
        }
        return null;
    }
}
