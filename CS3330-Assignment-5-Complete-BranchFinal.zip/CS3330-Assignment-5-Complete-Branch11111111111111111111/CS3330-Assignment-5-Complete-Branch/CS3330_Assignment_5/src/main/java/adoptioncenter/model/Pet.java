package adoptioncenter.model;

/**
 * Abstract base class for all pets.
 */
public abstract class Pet implements Comparable<Pet> {

    private Integer id;
    private String name;
    private String type;
    private String species;
    private Integer age;
    private Boolean adopted;

    /**
     * Default constructor.
     */
    public Pet() {
    }

    /**
     * Full constructor.
     * @param id ID of the pet
     * @param name Name of the pet
     * @param type Type (e.g., Dog, Cat)
     * @param species Breed or subspecies
     * @param age Age in years
     * @param adopted Adoption status
     */
    public Pet(Integer id, String name, String type, String species, Integer age, Boolean adopted) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.species = species;
        this.age = age;
        this.adopted = adopted;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getSpecies() { return species; }
    public void setSpecies(String species) { this.species = species; }

    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }

    public Boolean getAdopted() { return adopted; }
    public void setAdopted(Boolean adopted) { this.adopted = adopted; }

    /**
     * Abstract method to handle pet adoption logic.
     */
    public abstract void adopt();

    /**
     * Compare pets alphabetically by name (used in natural sort).
     * @param other The other pet to compare to
     * @return alphabetical comparison by name
     */
    @Override
    public int compareTo(Pet other) {
        return this.name.compareToIgnoreCase(other.name);
    }

    /**
     * String representation of a Pet.
     */
    @Override
    public String toString() {
        return "Pet [id=" + id +
               ", name=" + name +
               ", type=" + type +
               ", species=" + species +
               ", age=" + age +
               ", adopted=" + adopted + "]";
    }
}
