package adoptioncenter.model;

/**
 * Adapted pet from ExoticAnimal data.
 */
public class ExoticPet extends Pet {
    public ExoticPet(int id, String name, String type, String species, int age, boolean adopted) {
        super(id, name, type, species, age, adopted);
    }

    @Override
    public void adopt() {
        if (!getAdopted()) {
            System.out.println("Adopted Exotic Pet: " + getName());
            setAdopted(true);
        } else {
            System.out.println("Pet Already Adopted");
        }
    }
}
