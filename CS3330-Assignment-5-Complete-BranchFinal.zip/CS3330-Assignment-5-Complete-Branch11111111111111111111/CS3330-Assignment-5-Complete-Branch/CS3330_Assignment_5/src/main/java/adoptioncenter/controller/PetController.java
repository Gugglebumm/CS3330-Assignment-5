package adoptioncenter.controller;

import adoptioncenter.model.*;
import adoptioncenter.view.PetAdoptionGUI;

import javax.swing.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Controller class that links GUI actions with Shelter logic.
 */
public class PetController {
    private Shelter<Pet> shelter;
    private PetAdoptionGUI view;

    public PetController(Shelter<Pet> shelter, PetAdoptionGUI view) {
        this.shelter = shelter;
        this.view = view;
        initController();
    }

    private void initController() {
        view.setPetList(shelter.getPets());

        view.setAddPetAction(e -> {
            Pet pet = view.promptNewPet();
            if (pet != null) {
                // Set unique ID (increment from last)
                pet.setId(shelter.getPets().size() + 1);
                shelter.addPet(pet);
                view.setPetList(shelter.getPets());
            }
        });

        view.setAdoptPetAction(e -> {
            Pet selected = view.getSelectedPet();
            if (selected != null) {
                if (selected.getAdopted()) {
                    JOptionPane.showMessageDialog(view, "Already adopted.");
                } else {
                    selected.adopt();
                    view.setPetList(shelter.getPets());
                    JOptionPane.showMessageDialog(view, "Successfully adopted " + selected.getName() + "!");
                }
            }
        });

        view.setRemovePetAction(e -> {
            Pet selected = view.getSelectedPet();
            if (selected != null) {
                shelter.getPets().remove(selected);
                view.setPetList(shelter.getPets());
            }
        });

        view.setSortAction(option -> {
            Comparator<Pet> comparator;
            switch (option) {
                case "Age": comparator = new PetComparatorByAge(); break;
                case "Species": comparator = new PetComparatorBySpecies(); break;
                default: comparator = Comparator.naturalOrder(); break;
            }
            shelter.getPets().sort(comparator);
            view.setPetList(shelter.getPets());
        });

        view.setSaveAction(e -> {
            try {
                String filename = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + "_pets.json";
                FileWriter fw = new FileWriter(filename);
                new com.google.gson.GsonBuilder().setPrettyPrinting().create()
                    .toJson(shelter.getPets(), fw);
                fw.close();
                JOptionPane.showMessageDialog(view, "Saved to: " + filename);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(view, "Save failed: " + ex.getMessage());
            }
        });
    }
}
