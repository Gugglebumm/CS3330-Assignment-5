package adoptioncenter;

import adoptioncenter.model.*;
import adoptioncenter.view.PetAdoptionGUI;
import adoptioncenter.controller.PetController;

import javax.swing.*;
import java.util.List;

/**
 * Entry point for the Pet Adoption GUI Application.
 */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Shelter<Pet> shelter = new Shelter<>();

                // Load normal pets
                List<Pet> pets = PetLoader.loadPets("src/main/resources/pets.json");

                // Load exotic pets (optional)
                List<Pet> exoticPets = ExoticPetLoader.loadExoticPets("src/main/resources/exotic_pets.json", pets.size() + 1);

                // Combine all pets
                pets.addAll(exoticPets);
                for (Pet p : pets) {
                    shelter.addPet(p);
                }

                // Launch GUI
                PetAdoptionGUI gui = new PetAdoptionGUI();
                new PetController(shelter, gui);
                gui.setVisible(true);

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to load pets: " + e.getMessage());
            }
        });
    }
}
