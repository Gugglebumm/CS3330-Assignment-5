package adoptioncenter.model;

/**
 * Adapter to convert ExoticAnimal into a Pet-compatible ExoticPet.
 */
public class ExoticAnimalAdapter {
    public static ExoticPet adapt(ExoticAnimal animal, int id) {
        return new ExoticPet(
            id,
            animal.getAnimalName(),
            animal.getCategory(),
            animal.getSubSpecies(),
            animal.getYearsOld(),
            false
        );
    }
}
