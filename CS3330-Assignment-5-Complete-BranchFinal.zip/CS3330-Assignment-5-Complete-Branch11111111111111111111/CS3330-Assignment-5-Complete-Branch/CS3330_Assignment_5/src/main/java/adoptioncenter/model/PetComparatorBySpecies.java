package adoptioncenter.model;

import java.util.Comparator;

/**
 * Comparator for sorting pets by species.
 */
public class PetComparatorBySpecies implements Comparator<Pet> {
    @Override
    public int compare(Pet a, Pet b) {
        return a.getSpecies().compareToIgnoreCase(b.getSpecies());
    }
}
