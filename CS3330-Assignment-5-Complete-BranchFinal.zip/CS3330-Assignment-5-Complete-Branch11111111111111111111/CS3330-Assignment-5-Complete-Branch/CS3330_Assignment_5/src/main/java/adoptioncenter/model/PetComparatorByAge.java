package adoptioncenter.model;

import java.util.Comparator;

/**
 * Comparator for sorting pets by age.
 */
public class PetComparatorByAge implements Comparator<Pet> {
    @Override
    public int compare(Pet a, Pet b) {
        return Integer.compare(a.getAge(), b.getAge());
    }
}
