package adoptioncenter.model;

import com.google.gson.*;
import java.io.FileReader;
import java.util.*;

/**
 * Loads exotic pets using the adapter pattern.
 */
public class ExoticPetLoader {
    public static List<Pet> loadExoticPets(String filePath, int startingId) throws Exception {
        Gson gson = new Gson();
        ExoticAnimal[] animals = gson.fromJson(new FileReader(filePath), ExoticAnimal[].class);

        List<Pet> pets = new ArrayList<>();
        int id = startingId;
        for (ExoticAnimal animal : animals) {
            pets.add(ExoticAnimalAdapter.adapt(animal, id++));
        }
        return pets;
    }
}
